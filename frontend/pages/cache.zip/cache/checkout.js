import CheckOut from "../components/Cart/CheckOut"


const checkout = () => {
    return (
        <>
            <CheckOut />
        </>
    )
}

export default checkout
